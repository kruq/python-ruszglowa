from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='Narzędzia wyszukiwania dla książki Python. Rusz głową!',
    author='Dariusz Krukowski',
    author_email='dkrukowski@windowslive.com',
    url='helion.pl',
    modules=['vsearch']
)